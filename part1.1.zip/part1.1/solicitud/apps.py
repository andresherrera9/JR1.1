from django.apps import AppConfig


class SolicitudConfig(AppConfig):
    name = 'solicitud'
