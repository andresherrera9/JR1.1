from django.contrib import admin
from .models import entidad_opcion


admin.site.register(entidad_opcion)

