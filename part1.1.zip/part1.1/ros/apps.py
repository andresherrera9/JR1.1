from django.apps import AppConfig


class RosConfig(AppConfig):
    name = 'ros'
